document.addEventListener('DOMContentLoaded', function()
{
    let html = $("html").html()
    console.log(html)
    console.log(location);
});
